// In-memory stand-in for @supabase/supabase-js, used ONLY by the browser harness (tests/e2e).
// It implements just the calls the app makes, and exposes window.__fake so tests can change "server" data.

const iso = (n) => new Date(Date.UTC(2026, 9, 1, 0, 0, n)).toISOString();

const db = {
  version: 5,
  epoch: 1,
  calls: [],
  users: {
    'rakib@example.com': { password: 'secret123', confirmed: true, id: 'u-1', full_name: 'Rakib' },
    'admin@example.com': { password: 'adminpass1', confirmed: true, id: 'u-admin', full_name: 'Admin' },
    'editor@example.com': { password: 'editorpass1', confirmed: true, id: 'u-ed', full_name: 'Editor' },
  },
  audit: [],
  session: null,
  tables: {
    faqs: [{ id: 'f1', question_bn: 'আইনজীবী কি লাগবে?', question_en: 'Do I need a lawyer?', answer_bn: 'মামলার ধরনের ওপর নির্ভর করে।', answer_en: 'It depends on the case.', sort_order: 10, status: 'published', updated_at: iso(9) }],
    notices: [{ id: 'n1', kind: 'update', title_bn: 'আইন হালনাগাদ', title_en: 'Law update', body_bn: 'দণ্ডবিধির তথ্য যাচাই হয়েছে।', body_en: 'Penal Code details verified.', status: 'published', updated_at: iso(8) }],
    legal_pages: [],
  },
  settings: {
    maintenance_mode: { enabled: false, message_bn: '', message_en: '' },
    min_app_version: '0.0.1',
    feature_flags: { land_calculator: false },
    contact: { email: '' },
    lawyer_pricing: { contact_fee: 50, rating_fee: 2500, bkash_number: '01711111111', note_bn: '', note_en: 'Fees are not refunded.' },
  },
  reports: [{ id: 'r0', user_id: 'u-1', target_type: 'law', target_id: 'l1', message: 'Penalty text looks outdated', status: 'open', created_at: '2026-10-05T00:00:00Z' }],
  error_logs: [],
  lawyers: [
    { id: 'lw1', user_id: 'u-L1', full_name: 'Ayesha Rahman', enrollment_no: 'DBA-1234', enrollment_year: 2015, bar_association: 'Dhaka Bar', courts: ['lower_courts', 'high_court_division'], practice_areas: ['land-law', 'family-law'], district: 'dhaka', office_address: '12 Court Road, Dhaka', phone: '01700000001', email: 'ayesha@example.com', qualifications: 'LL.B, LL.M', education: 'LL.B (Dhaka University)', practising_since: 2015, cases_handled: 200, cases_won: 120, achievements: 'Best junior advocate 2018', certificate_paths: ['u-L1/llb.pdf'], consent_public: true, status: 'verified', verified_at: '2026-10-10T00:00:00Z', review_note: null },
    { id: 'lw2', user_id: 'u-L2', full_name: 'Bashir Ahmed', enrollment_no: '5678', enrollment_year: 2010, bar_association: 'Sylhet Bar', courts: ['lower_courts'], practice_areas: ['criminal-law'], district: 'sylhet', office_address: '5 Bar Lane, Sylhet', phone: '01800000002', email: null, qualifications: null, education: null, practising_since: null, cases_handled: null, cases_won: null, achievements: null, certificate_paths: ['u-L2/cert.png'], consent_public: true, status: 'verified', verified_at: '2026-10-11T00:00:00Z', review_note: null },
    { id: 'lw3', user_id: 'u-L3', full_name: 'Pending Person', enrollment_no: '999', enrollment_year: null, bar_association: 'Dhaka Bar', courts: ['lower_courts'], practice_areas: ['land-law'], district: 'dhaka', office_address: '1 Hidden Road', phone: '01900000003', email: null, certificate_paths: ['u-L3/x.pdf'], consent_public: true, status: 'pending', verified_at: null, review_note: null },
  ],
  payments: [],
  ratings: [],
  files: {},
  profiles: {
    'u-1': { id: 'u-1', full_name: 'Rakib', role: 'user', preferred_lang: 'bn' },
    'u-admin': { id: 'u-admin', full_name: 'Admin', role: 'admin', preferred_lang: 'bn' },
    'u-ed': { id: 'u-ed', full_name: 'Editor', role: 'editor', preferred_lang: 'bn' },
  },
};

let authListener = null;
const sameDate = (a, b) => Date.parse(a) === Date.parse(b);

function parseKeyset(filter) {
  let m = /^updated_at\.gte\."([^"]+)"$/.exec(filter);
  if (m) return (r) => Date.parse(r.updated_at) >= Date.parse(m[1]);
  m = /^updated_at\.gt\."([^"]+)",and\(updated_at\.eq\."([^"]+)",id\.gt\.(.+)\)$/.exec(filter);
  if (m) return (r) => Date.parse(r.updated_at) > Date.parse(m[1]) || (sameDate(r.updated_at, m[2]) && r.id > m[3]);
  throw new Error(`fake-supabase: unsupported or() filter: ${filter}`);
}

const CONTENT = new Set(['categories', 'laws', 'law_sections', 'faqs', 'notices', 'legal_pages']);
let idSeq = 0;
const nowIso = () => new Date(Date.UTC(2026, 9, 3, 0, 0, ++idSeq)).toISOString();

function role() {
  return db.session ? db.profiles[db.session.user.id]?.role || 'user' : 'anon';
}
const isStaff = () => role() === 'editor' || role() === 'admin';
const isAdmin = () => role() === 'admin';
const denied = (msg = 'new row violates row-level security policy') => ({ data: null, error: { code: '42501', message: msg } });

function audit(action, table, oldRow, newRow) {
  db.audit.unshift({ id: db.audit.length + 1, actor: db.session?.user.id || null, action, table_name: table, row_id: (newRow || oldRow).id, old_data: oldRow || null, new_data: newRow || null, at: nowIso() });
}

class Query {
  constructor(table) {
    this.table = table;
    this.op = 'select';
    this.preds = [];
    this.orders = [];
    this.lim = Infinity;
    this.single = false;
    this.payload = null;
    this.head = false;
    this.count = false;
  }
  select(_cols, opts = {}) { this.cols = typeof _cols === 'string' ? _cols : '*'; this.head = Boolean(opts.head); this.count = Boolean(opts.count); return this; }
  eq(col, val) { this.preds.push((r) => r[col] === val); return this; }
  gte(col, val) { this.preds.push((r) => Date.parse(r[col]) >= Date.parse(val)); return this; }
  order(col, { ascending = true } = {}) { this.orders.push([col, ascending]); return this; }
  limit(n) { this.lim = n; return this; }
  or(filter) { this.preds.push(parseKeyset(filter)); return this; }
  maybeSingle() { this.single = true; return this; }
  insert(rows) { this.op = 'insert'; this.payload = rows; return this; }
  update(values) { this.op = 'update'; this.payload = values; return this; }
  delete() { this.op = 'delete'; return this; }
  upsert(rows) { this.op = 'upsert'; this.payload = rows; return this; }
  then(resolve, reject) { return Promise.resolve(this.exec()).then(resolve, reject); }

  exec() {
    db.calls.push(`${this.op}:${this.table}`);
    if (!db.online) return { data: null, error: new Error('Failed to fetch') };
    const t = this.table;

    if (t === 'content_meta') return { data: { content_version: db.version, epoch: db.epoch }, error: null };

    if (t === 'app_settings') {
      if (this.op === 'upsert') {
        if (!isAdmin()) return denied();
        for (const r of this.payload) db.settings[r.key] = r.value;
        db.version += 1;
        return { data: null, error: null };
      }
      return { data: Object.entries(db.settings).map(([key, value]) => ({ key, value })), error: null };
    }

    if (t === 'profiles') {
      const list = Object.values(db.profiles);
      if (this.op === 'update') {
        const target = list.find((r) => this.preds.every((f) => f(r)));
        if (!target) return { data: null, error: null };
        const self = db.session && target.id === db.session.user.id;
        if (!self && !isAdmin()) return denied();
        if ('role' in this.payload && !isAdmin()) return denied('only admins can change roles');
        Object.assign(target, this.payload);
        return { data: null, error: null };
      }
      const p = list.find((r) => this.preds.every((f) => f(r)));
      return { data: p ? { ...p } : null, error: null };
    }

    if (t === 'error_logs') {
      if (this.op === 'insert') { db.error_logs.push(...[].concat(this.payload)); return { data: null, error: null }; }
      if (!isAdmin()) return { data: [], error: null };
      return this.finish(db.error_logs.map((r, i) => ({ id: i + 1, created_at: nowIso(), ...r })));
    }

    if (t === 'reports') {
      if (this.op === 'insert') {
        if (!db.session) return denied();
        db.reports.push(...[].concat(this.payload).map((r, i) => ({ id: `r${db.reports.length + i + 1}`, user_id: db.session.user.id, status: 'open', created_at: nowIso(), ...r })));
        return { data: null, error: null };
      }
      if (this.op === 'update') {
        if (!isStaff()) return denied();
        db.reports.filter((r) => this.preds.every((f) => f(r))).forEach((r) => Object.assign(r, this.payload));
        return { data: null, error: null };
      }
      return this.finish(db.reports.filter((r) => (isStaff() || r.user_id === db.session?.user.id) && this.preds.every((f) => f(r))).map((r) => ({ ...r })));
    }

    if (t === 'lawyers_public') {
      const cols = (this.cols || '*').split(',').map((x) => x.trim());
      if (cols.includes('*') || cols.includes('phone') || cols.includes('email')) return { data: null, error: { code: '42703', message: 'column lawyers_public.phone does not exist' } };
      const rows = db.lawyers.filter((r) => r.status === 'verified' && this.preds.every((f) => f(r))).map((r) => {
        const o = { ...r };
        delete o.status; delete o.review_note; delete o.user_id; delete o.consent_public; delete o.phone; delete o.email;
        const vis = db.ratings.filter((x) => x.lawyer_id === r.id && x.status === 'visible');
        o.rating_count = vis.length;
        o.rating_avg = vis.length ? Math.round((vis.reduce((a, x) => a + x.stars, 0) / vis.length) * 10) / 10 : null;
        return o;
      });
      return this.finish(rows);
    }

    if (t === 'lawyer_ratings_public') {
      return this.finish(db.ratings.filter((r) => r.status === 'visible' && this.preds.every((f) => f(r))).map((r) => ({ id: r.id, lawyer_id: r.lawyer_id, stars: r.stars, comment: r.comment, created_at: r.created_at })));
    }

    if (t === 'lawyer_ratings') {
      if (!db.session) return denied('permission denied for table lawyer_ratings');
      const me = db.session.user.id;
      if (this.op === 'update') {
        if (!isAdmin()) return { data: this.cols ? [] : null, error: null };
        const hit = db.ratings.filter((r) => this.preds.every((f) => f(r)));
        hit.forEach((r) => { if (this.payload.status) r.status = this.payload.status; });
        return { data: this.cols ? hit.map((r) => ({ ...r })) : null, error: null };
      }
      return this.finish(db.ratings.filter((r) => (isAdmin() || r.user_id === me) && this.preds.every((f) => f(r))).map((r) => ({ ...r })));
    }

    if (t === 'lawyer_payments') {
      if (!db.session) return denied('permission denied for table lawyer_payments');
      const me = db.session.user.id;
      if (this.op === 'insert') {
        const row = [].concat(this.payload)[0];
        const l = db.lawyers.find((x) => x.id === row.lawyer_id && x.status === 'verified');
        if (!l) return { data: null, error: { code: '23514', message: 'This advocate is not listed' } };
        if (l.user_id === me) return { data: null, error: { code: '23514', message: 'You can not pay for your own listing' } };
        const trx = String(row.trx_id).replace(/\s/g, '').toUpperCase();
        if (db.payments.some((p) => p.status !== 'rejected' && (p.trx_id === trx || (p.user_id === me && p.lawyer_id === row.lawyer_id && p.kind === row.kind)))) return { data: null, error: { code: '23505', message: 'duplicate key value violates unique constraint' } };
        const fee = db.settings.lawyer_pricing[row.kind === 'contact' ? 'contact_fee' : 'rating_fee'];
        db.payments.push({ id: `py${db.payments.length + 1}`, user_id: me, lawyer_id: l.id, lawyer_name: l.full_name, kind: row.kind, amount_bdt: fee, method: 'bkash', sender_number: row.sender_number, trx_id: trx, status: 'pending', review_note: null, created_at: nowIso() });
        return { data: null, error: null };
      }
      if (this.op === 'update') {
        if (!isAdmin()) return { data: this.cols ? [] : null, error: null };
        const hit = db.payments.filter((r) => this.preds.every((f) => f(r)));
        for (const r of hit) {
          if (r.status !== 'pending') return { data: null, error: { code: '23514', message: 'A decided payment can not be changed' } };
          if (this.payload.status === 'rejected' && !String(this.payload.review_note || '').trim()) return { data: null, error: { code: '23514', message: 'A reason is required when rejecting a payment' } };
          Object.assign(r, { status: this.payload.status, review_note: this.payload.review_note || null, reviewed_by: db.session.user.id, reviewed_at: nowIso() });
        }
        return { data: this.cols ? hit.map((r) => ({ ...r })) : null, error: null };
      }
      return this.finish(db.payments.filter((r) => (isAdmin() || r.user_id === me) && this.preds.every((f) => f(r))).map((r) => ({ ...r })));
    }

    if (t === 'lawyer_profiles') {
      if (!db.session) return denied('permission denied for table lawyer_profiles');
      const me = db.session.user.id;
      if (this.op === 'insert') {
        if (db.lawyers.some((r) => r.user_id === me)) return { data: null, error: { code: '23505', message: 'duplicate key value violates unique constraint' } };
        const row = { ...[].concat(this.payload)[0], id: `lw${db.lawyers.length + 1}`, user_id: me, status: 'pending', verified_at: null, review_note: null };
        db.lawyers.push(row);
        return { data: null, error: null };
      }
      const mine = db.lawyers.filter((r) => (r.user_id === me || isAdmin()) && this.preds.every((f) => f(r)));
      if (this.op === 'update') {
        for (const r of mine) {
          const edit = { ...this.payload };
          if (!isAdmin()) { delete edit.status; delete edit.review_note; delete edit.verified_at; }
          const changed = Object.keys(edit).some((k) => JSON.stringify(edit[k]) !== JSON.stringify(r[k]));
          Object.assign(r, edit);
          if (!isAdmin() && changed && (r.status === 'verified' || r.status === 'rejected')) Object.assign(r, { status: 'pending', verified_at: null, review_note: null });
          if (isAdmin() && edit.status === 'verified') r.verified_at = nowIso();
        }
        return { data: this.cols ? mine.map((r) => ({ ...r })) : null, error: null };
      }
      if (this.op === 'delete') {
        db.lawyers = db.lawyers.filter((r) => !mine.includes(r));
        return { data: null, error: null };
      }
      return this.finish(mine.map((r) => ({ ...r })));
    }

    if (t === 'audit_log') {
      if (!isAdmin()) return denied('permission denied for table audit_log');
      return this.finish(db.audit.filter((r) => this.preds.every((f) => f(r))).map((r) => ({ ...r })));
    }

    // content tables
    const list = db.tables[t] || (db.tables[t] = []);
    if (this.op === 'insert') {
      if (!isStaff()) return denied();
      for (const row of [].concat(this.payload)) {
        if (row.slug && list.some((r) => r.slug === row.slug)) return { data: null, error: { code: '23505', message: 'duplicate key value violates unique constraint' } };
        const next = { id: row.id || `g${++idSeq}`, status: 'draft', ...row, updated_at: nowIso() };
        list.push(next);
        audit('INSERT', t, null, next);
      }
      db.version += 1;
      return { data: null, error: null };
    }
    if (this.op === 'update') {
      if (!isStaff()) return { data: null, error: null }; // RLS: silently matches nothing
      const hits = list.filter((r) => this.preds.every((f) => f(r)));
      for (const r of hits) {
        if (r.status === 'published' && this.payload.status === 'draft') return { data: null, error: { code: '23514', message: 'A published item cannot go back to draft. Archive it instead.' } };
        const before = { ...r };
        Object.assign(r, this.payload, { updated_at: nowIso() });
        audit('UPDATE', t, before, { ...r });
      }
      db.version += 1;
      return { data: null, error: null };
    }
    if (this.op === 'delete') {
      if (!isAdmin()) return { data: null, error: null };
      const gone = list.filter((r) => this.preds.every((f) => f(r)));
      gone.forEach((r) => audit('DELETE', t, { ...r }, null));
      db.tables[t] = list.filter((r) => !gone.includes(r));
      db.epoch += 1;
      db.version += 1;
      return { data: null, error: null };
    }
    const visible = list.filter((r) => (isStaff() || r.status === 'published' || r.status === 'archived') && this.preds.every((f) => f(r)));
    return this.finish(visible.map((r) => ({ ...r })));
  }

  finish(rows) {
    for (const [col, asc] of [...this.orders].reverse()) {
      rows.sort((a, b) => {
        const x = col === 'updated_at' || col === 'created_at' || col === 'at' ? Date.parse(a[col]) : a[col];
        const y = col === 'updated_at' || col === 'created_at' || col === 'at' ? Date.parse(b[col]) : b[col];
        return (x < y ? -1 : x > y ? 1 : 0) * (asc ? 1 : -1);
      });
    }
    if (this.count && this.head) return { count: rows.length, data: null, error: null };
    const out = rows.slice(0, this.lim);
    return { data: this.single ? out[0] || null : out, error: null };
  }
}

const sessionFor = (email) => {
  const u = db.users[email];
  return { user: { id: u.id, email, identities: [{}] }, access_token: 'tok' };
};

export function createClient() {
  return {
    from: (table) => new Query(table),
    storage: {
      from: (bucket) => ({
        async upload(path, file) {
          if (!db.session) return { error: { message: 'not signed in' } };
          if (!path.startsWith(`${db.session.user.id}/`)) return { error: { code: '42501', message: 'new row violates row-level security policy' } };
          db.files[`${bucket}/${path}`] = { size: file.size, type: file.type };
          return { error: null };
        },
        async createSignedUrl(path) { return { data: { signedUrl: `https://files.example.test/${bucket}/${path}?token=t` }, error: null }; },
        async remove(paths) { paths.forEach((p) => delete db.files[`${bucket}/${p}`]); return { error: null }; },
      }),
    },
    rpc: async (name, args = {}) => {
      db.calls.push(`rpc:${name}`);
      if (!db.online) return { error: new Error('Failed to fetch') };
      if (name === 'delete_my_account') {
        if (!db.session) return { error: { message: 'not signed in' } };
        const email = db.session.user.email;
        delete db.users[email];
        return { error: null };
      }
      if (name === 'admin_list_users') {
        if (role() !== 'admin') return { data: null, error: { code: '42501', message: 'admins only' } };
        return { data: Object.entries(db.users).map(([email, u]) => ({ id: u.id, email, full_name: u.full_name, role: db.profiles[u.id]?.role || 'user', created_at: '2026-10-01T00:00:00Z' })), error: null };
      }
      if (name === 'purge_old_error_logs') return { data: 0, error: null };
      if (name === 'get_lawyer_contact') {
        if (!db.session) return { data: null, error: { code: '28000', message: 'not signed in' } };
        const me = db.session.user.id;
        const l = db.lawyers.find((x) => x.id === args.p_lawyer && x.status === 'verified');
        const paid = db.payments.some((p) => p.user_id === me && p.lawyer_id === args.p_lawyer && p.kind === 'contact' && p.status === 'approved');
        if (!l || !(paid || isAdmin() || l.user_id === me)) return { data: null, error: { code: '42501', message: 'The contact fee has not been paid' } };
        return { data: [{ phone: l.phone, email: l.email }], error: null };
      }
      if (name === 'submit_lawyer_rating') {
        if (!db.session) return { data: null, error: { code: '28000', message: 'not signed in' } };
        const me = db.session.user.id;
        const l = db.lawyers.find((x) => x.id === args.p_lawyer && x.status === 'verified');
        if (!l) return { data: null, error: { code: '23514', message: 'This advocate is not listed' } };
        if (l.user_id === me) return { data: null, error: { code: '23514', message: 'You can not rate yourself' } };
        const pay = db.payments.find((p) => p.user_id === me && p.lawyer_id === l.id && p.kind === 'rating' && p.status === 'approved');
        if (!pay) return { data: null, error: { code: '42501', message: 'An approved rating payment is required' } };
        if (db.ratings.some((r) => r.lawyer_id === l.id && r.user_id === me)) return { data: null, error: { code: '23505', message: 'duplicate key value violates unique constraint' } };
        const row = { id: `rt${db.ratings.length + 1}`, lawyer_id: l.id, user_id: me, stars: args.p_stars, comment: args.p_comment || null, status: 'visible', created_at: nowIso() };
        db.ratings.push(row);
        return { data: row.id, error: null };
      }
      return { error: { message: `unknown rpc ${name}` } };
    },
    auth: {
      async getSession() { return { data: { session: db.session } }; },
      onAuthStateChange(cb) { authListener = cb; return { data: { subscription: { unsubscribe() {} } } }; },
      async signInWithPassword({ email, password }) {
        if (!db.online) return { error: new Error('Failed to fetch') };
        const u = db.users[email];
        if (!u || u.password !== password) return { error: { message: 'Invalid login credentials', status: 400 } };
        db.session = sessionFor(email);
        authListener?.('SIGNED_IN', db.session);
        return { data: { session: db.session }, error: null };
      },
      async signUp({ email, password, options }) {
        if (!db.online) return { error: new Error('Failed to fetch') };
        if (db.users[email]) return { data: { user: { identities: [] }, session: null }, error: null };
        db.users[email] = { password, confirmed: !db.requireConfirm, id: `u-${Object.keys(db.users).length + 1}`, full_name: options?.data?.full_name };
        if (db.requireConfirm) return { data: { user: { id: db.users[email].id, identities: [{}] }, session: null }, error: null };
        db.session = sessionFor(email);
        authListener?.('SIGNED_IN', db.session);
        return { data: { user: db.session.user, session: db.session }, error: null };
      },
      async signOut() { db.session = null; authListener?.('SIGNED_OUT', null); return { error: null }; },
      async resetPasswordForEmail(email) { db.calls.push(`reset:${email}`); return { error: null }; },
      async updateUser() { return { error: null }; },
    },
  };
}

db.online = true;
globalThis.__fake = {
  db,
  bump() { db.version += 1; },
  setSetting(key, value) { db.settings[key] = value; db.version += 1; },
  upsert(table, row) {
    const list = db.tables[table];
    const i = list.findIndex((r) => r.id === row.id);
    const next = { ...(i >= 0 ? list[i] : {}), ...row, updated_at: new Date(Date.UTC(2026, 9, 2, 0, 0, db.version * 10)).toISOString() };
    if (i >= 0) list[i] = next; else list.push(next);
    db.version += 1;
  },
  hardDelete(table, id) { db.tables[table] = db.tables[table].filter((r) => r.id !== id); db.epoch += 1; db.version += 1; },
  reset() { db.calls.length = 0; },
};
